title: Docker命令
date: '2019-10-30 11:50:44'
updated: '2019-10-30 11:50:44'
tags: [Docker]
permalink: /articles/2019/10/30/1572407444699.html
---
```
管理命令：
  container     管理容器
  image         管理镜像
  network       管理网络
  node          管理Swarm节点
  plugin        管理插件
  secret        管理Docker secrets
  service       管理服务
  stack         管理Docker stacks
  swarm         管理Swarm集群
  system        查看系统信息
  volume        管理卷

  如：docker container ls 显示所有容器

普通命令：


  // 开发应该熟练掌握的:
  images        查看镜像列表
  rmi           删除镜像
  save          将指定镜像保存成 tar 归档文件
  load          从存档或者STDIN加载镜像
  build         从一个DockerFile构建镜像
  commit        从容器创建一个镜像

  create        创建一个容器
  run           创建一个新的容器并运行一个命令
  rename        重命名容器
  start         启动容器
  stop          停止容器
  restart       重启容器
  rm            删除容器
  logs          获取一个容器的日志
  exec          在正在运行的容器中运行命令
  cp            从容器和主机文件系统之间拷贝文件 
  ps            查看容器列表


  // 运维应该熟练掌握的: 
  login         登陆docker镜像仓库
  logout        退出docker镜像仓库
  search        从Docker Hub搜索镜像
  pull          从镜像仓库拉取镜像
  push          将本地的镜像上传到镜像仓库,要先登陆到镜像仓库
  tag           标记本地镜像，将其归入某一仓库
  export        将容器的文件系统导出为tar存档
  import        从归档文件中创建镜像

  info          显示系统范围的信息
  version       显示Docker的版本信息
  stats         显示（实时）容器资源使用情况的统计信息
  inspect       显示Docker对象的低级信息（查看对象详情）
  diff          显示容器文件系统上的更改（查看容器变化）
  events        显示从服务器获取实时事件（可查看docker的改动）
  port          显示端口映射或容器的特定映射列表（端口查看）
  top           显示一个容器中运行的进程（查看进程）
  history       显示镜像的历史记录

  attach        进入一个运行的容器
  pause         暂停一个或多个容器中的所有进程
  unpause       恢复容器中所有的进程
  kill          kill运行中的容器
  wait          阻塞直到容器停止，然后打印退出代码

  update        更新容器配置
```
